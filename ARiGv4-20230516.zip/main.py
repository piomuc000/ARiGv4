from setup import Setup
from genetic import Genetic


if __name__ == '__main__':
    print('ARiGv4')
    setup = Setup()
    setup.set_adaptation("inverted_egg_holder")
    setup.set_ranges(-512, 512)
    setup.create_animal_list(1000)
    genetic_task = Genetic()
    genetic_task.load_setup(setup)
    genetic_task.execute()
