# import plot_surface
from setup import Setup
from genetic import Genetic


if __name__ == '__main__':
    print('ARiGv4')
    # plot_surface.plot_surface(-100, 100, -100, 100, 'inverted_him')
    setup = Setup()
    setup.set_adaptation("inverted_him")
    setup.set_ranges(-100, 100)
    setup.create_animal_list(3)
    genetic_task = Genetic()
    genetic_task.load_setup(setup)
    genetic_task.execute()
