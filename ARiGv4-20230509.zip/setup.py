from surface_functions import SurfaceFunctions
from animal_list import AnimalList
from animal import Animal
import numpy as np


class Setup:
    def __init__(self):
        self.x_start = 0.0
        self.x_end = 0.0
        self.y_start = 0.0
        self.y_end = 0.0
        self.ranges_set = False
        self.sfo = None
        self.animal_list = None
        self.best_animal = None

    def set_adaptation(self, adaptation: str):
        sfo = SurfaceFunctions()
        sfo.select_function(adaptation)
        self.sfo = sfo
        return sfo

    def get_adaptation_object(self):
        return self.sfo or ValueError(f"Surface function not configured")

    def set_ranges(self, x_start: float, x_end: float, y_start: float = None, y_end: float = None):
        self.x_start = x_start
        self.x_end = x_end
        self.y_start = y_start or x_start
        self.y_end = y_end or x_end
        self.ranges_set = True

    def get_ranges(self):
        if self.ranges_set:
            return self.x_start, self.x_end, self.y_start, self.y_end
        else:
            raise ValueError(f"Ranges not configured")

    def create_animal_list(self, count: int):
        if self.ranges_set and self.sfo is not None:
            self.animal_list = AnimalList()
            for animal_number in range(count):
                animal_tmp = Animal()
                animal_tmp.set_sfo(self.sfo)
                var1, var2 = self.random_x_y()
                animal_tmp.set_features(x1=var1, x2=var2)
                self.animal_list.add_animal(animal_tmp)
            return self.animal_list
        else:
            raise ValueError(f"Setup object not configured yet to create animal list")

    def get_animal_list(self):
        return self.animal_list or ValueError(f"Animal list not initialized")

    def random_x_y(self):
        var1 = np.random.uniform(self.x_start, self.x_end)
        var2 = np.random.uniform(self.y_start, self.y_end)
        return var1, var2

    def store_best_animal(self, animal: Animal):
        if self.best_animal is None:
            self.best_animal = animal
        elif animal.get_adaptation() > self.best_animal.get_adaptation():
            self.best_animal = animal

    def get_best_animal(self):
        return self.best_animal or ValueError(f"No best animal saved yet")
