class Genetic:
    def __init__(self):
        self.animal_list = None
        self.generation_counter = 0
        self.setup = None
        self.animal_list = None

    def load_setup(self, setup):
        self.setup = setup
        self.animal_list = self.setup.get_animal_list()

    def execute(self):
        print(f"sie roby")
